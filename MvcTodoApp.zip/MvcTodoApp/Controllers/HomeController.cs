using Microsoft.AspNetCore.Mvc;
using MvcTodoApp.Models;
using System.Collections.Generic;
using System.Linq;

namespace MvcTodoApp.Controllers
{
    public class HomeController : Controller
    {
        // قائمة محاكاة لقاعدة البيانات (في الذاكرة)
        private static List<TaskItem> tasks = new List<TaskItem>
        {
            new TaskItem { Id = 1, Title = "تدرب على MVC Design Pattern", IsComplete = false },
            new TaskItem { Id = 2, Title = "تدرب على N-tier Architecture", IsComplete = false },
            new TaskItem { Id = 3, Title = "تدرب على استخدام git", IsComplete = false },
        };

        /// <summary>
        /// يعرض القائمة الرئيسية للمهام.
        /// </summary>
        public IActionResult Index()
        {
            return View(tasks);
        }

        /// <summary>
        /// إضافة مهمة جديدة.
        /// </summary>
        [HttpPost]
        public IActionResult AddTask(string title)
        {
            if (!string.IsNullOrWhiteSpace(title))
            {
                var newTask = new TaskItem
                {
                    Id = tasks.Any() ? tasks.Max(t => t.Id) + 1 : 1,
                    Title = title,
                    IsComplete = false
                };

                tasks.Add(newTask);
            }

            return RedirectToAction("Index");
        }

        /// <summary>
        /// تعيين مهمة كمكتملة.
        /// </summary>
        [HttpPost]
        public IActionResult CompleteTask(int id)
        {
            var task = tasks.FirstOrDefault(t => t.Id == id);

            if (task != null)
            {
                task.IsComplete = true;
            }

            return RedirectToAction("Index");
        }

        /// <summary>
        /// تعديل عنوان المهمة.
        /// </summary>
        [HttpPost]
        public IActionResult EditTask(int id, string newTitle)
        {
            // البحث عن المهمة باستخدام id
            var task = tasks.FirstOrDefault(t => t.Id == id);

            // التأكد من أن المهمة موجودة وأن العنوان الجديد صالح
            if (task != null && !string.IsNullOrWhiteSpace(newTitle))
            {
                // تعديل العنوان
                task.Title = newTitle;
            }

            return RedirectToAction("Index");
        }
        [HttpPost]
        public IActionResult DeleteTask(int id)
        {
          // البحث عن المهمة
            var task = tasks.FirstOrDefault(t => t.Id == id);

         // إذا وُجدت نحذفها
        if (task != null)
        {
            tasks.Remove(task);
        }

        return RedirectToAction("Index");
        }
    }
}